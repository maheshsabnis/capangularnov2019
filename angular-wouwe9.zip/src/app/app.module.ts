import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {SimpleComponent} from './simplecomponent/app.simple.component';
import {ProductComponent} from  './productcomponent/app.product.component';
import {ProductValidationComponent}  from './productvalidationcomponent/app.product.validation.component';
// imports: array to import and load standard angular modules as well as external modules
// in current application
// declarations: array to declare all components/pipes/directives developed by developers
// bootstrap: array to load/bootstarp components to browser when app is executed

@NgModule({
  imports:      [ BrowserModule, FormsModule, ReactiveFormsModule ],
  declarations: [SimpleComponent, ProductComponent, ProductValidationComponent], 
  bootstrap:    [ProductValidationComponent]
})
export class AppModule { }
