import {Component, OnInit} from '@angular/core';
import {Product} from './app.product.model';
import {ProductLogic} from './app.logic';
import {Categories, Manufacturers} from './app.constants';
// the OnInit interface implemented by Component class
// this interface provides the 'ngOnInit()' method
// this method is invoked immediately after the component's constructor
// write the logic in this method, this is such a logic that may reduce
// the component's constructor performance if it is written in constructor

@Component({
  selector:'app-product-component',
  templateUrl:'./app.product.component.view.html'
})
export class ProductComponent implements OnInit {
  product: Product;
  private logic: ProductLogic;
  products: Array<Product>;
  headers: Array<string>;
  // store the constances in local public members of class
  categories = Categories;
  manufacturers = Manufacturers;
  constructor(){
    this.product  =new Product(0,'','','','','',0);
    this.logic = new ProductLogic();
    this.products = new Array<Product>();
    this.headers = new Array<string>();
  }

  clear(): void {
      this.product  =new Product(0,'','','','','',0);
  }
  save(): void {
    this.products = this.logic.saveProduct(this.product);
    alert(JSON.stringify(this.products));
  }
  ngOnInit():void {
    // iterate over the product object to read all its public members
    for(let p in this.product){
      this.headers.push(p);
    }
    this.products = this.logic.getProducts();
  }

  getSelectedProduct(p:Product):void {
    // Object.assign() will create a separate location where p is stored
    // the product now points to this location
    this.product = Object.assign({},p);
  } 
}