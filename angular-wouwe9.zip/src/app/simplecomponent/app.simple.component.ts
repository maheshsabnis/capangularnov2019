import {Component} from '@angular/core'; 

// the Component decorator will make the class as Angular component
// Component decorator has followign properties
// 1. selector: the string that represents custom html tag to load the component in browser
// 2. template: for inline HTML that will be rendered when component is loaded
// 3. templateUrl: an external HTML file that will be rendered when component is loaded
// 4. style/styleUrls: internal and external class
// 5: providers: To register the Angular service for this component only

@Component({
  selector:'app-simple-component',
  templateUrl:'app.simple.component.view.html'
})
export class SimpleComponent {
    message: string;
    name: string;
    constructor(){
      this.message = "I am the Original message";
      this.name = "";
    }

    display():void {
      this.message = "I am changed";
    }
}